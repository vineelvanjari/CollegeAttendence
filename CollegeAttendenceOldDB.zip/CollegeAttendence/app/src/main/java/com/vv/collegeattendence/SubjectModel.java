package com.vv.collegeattendence;

public class SubjectModel {
   public String subjectName;
   public String year;
   public String section;

    public SubjectModel(String subjectName,String year,String section){
        this.subjectName=subjectName;
        this.year=year;
        this.section=section;
    }
}
