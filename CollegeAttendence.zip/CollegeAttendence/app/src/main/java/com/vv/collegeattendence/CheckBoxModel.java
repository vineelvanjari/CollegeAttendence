package com.vv.collegeattendence;

public class CheckBoxModel {
    public  int id;
    public boolean presentAbsent;
    CheckBoxModel(int id,boolean presentAbsent){
        this.id=id;
        this.presentAbsent=presentAbsent;
    }
}
